// Nen5e — Script da Ficha de Personagem
// Calcula modificadores de atributos automaticamente

(function () {
  const ids = ["FOR", "DES", "CON", "INT", "SAB", "CAR"];

  function mod(v) {
    const m = Math.floor((v - 10) / 2);
    return (m >= 0 ? "+" : "") + m;
  }

  document.querySelectorAll('input[type="number"]').forEach(function (inp) {
    const field = inp.closest(".field");
    if (!field) return;
    const label = field.querySelector(".statlab");
    if (!label) return;
    const att = label.textContent.trim();
    if (!ids.includes(att)) return;

    const m = document.getElementById("mod" + att);
    function upd() {
      const v = parseInt(inp.value) || 10;
      if (m) m.textContent = mod(v);
    }
    inp.addEventListener("input", upd);
    upd();
  });
})();
