(() => {
  const tabs = [...document.querySelectorAll('[role="tab"]')];
  const activate = (tab, moveFocus = false) => {
    tabs.forEach((candidate) => {
      const selected = candidate === tab;
      candidate.setAttribute("aria-selected", String(selected));
      candidate.tabIndex = selected ? 0 : -1;
      const panel = document.getElementById(candidate.getAttribute("aria-controls"));
      if (panel) panel.hidden = !selected;
    });
    if (moveFocus) tab.focus();
  };
  tabs.forEach((tab, index) => {
    tab.addEventListener("click", () => activate(tab));
    tab.addEventListener("keydown", (event) => {
      let next = index;
      if (event.key === "ArrowRight" || event.key === "ArrowDown") next = (index + 1) % tabs.length;
      if (event.key === "ArrowLeft" || event.key === "ArrowUp") next = (index - 1 + tabs.length) % tabs.length;
      if (event.key === "Home") next = 0;
      if (event.key === "End") next = tabs.length - 1;
      if (next !== index || event.key === "Home" || event.key === "End") {
        event.preventDefault();
        activate(tabs[next], true);
      }
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        activate(tab, true);
      }
    });
  });
  const initial = tabs.find((tab) => tab.getAttribute("aria-selected") === "true") || tabs[0];
  if (initial) activate(initial);
})();
