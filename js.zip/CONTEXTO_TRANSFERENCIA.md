# CONTEXTO DE TRANSFERÊNCIA — Sistema Nen5e

**Projeto:** Reforma completa do sistema HxH da campanha do Sr. Maycon  
**Base mecânica:** D&D 5e (Livro do Jogador)  
**Sistema de poder:** Técnicas de Aura / Nen (baseado em F&M / Feiticeiros & Maldições e Aura RPG)  
**Versão:** 2.2 (último commit)  
**Local:** `C:\Users\Maycon\Documents\RPG_Nen5e`  
**Controle de versão:** Git — 4 commits (v1.0, v2.0, v2.1, v2.2). Cada commit é um ponto de restauração.

---

## 1. O que este contexto faz

Cole este texto como a **primeira mensagem de uma nova sessão do Hermes**. Ele resume tudo o que já foi construído, onde estão os arquivos, as decisões de design e como continuar o projeto sem precisar reler tudo.

---

## 2. Estrutura de pastas e arquivos

```
RPG_Nen5e/
├── index.html              # Capa, como jogar, princípios de ouro, navegação
├── LEIAME.md               # Resumo do sistema
├── CONTEXTO_TRANSFERENCIA.md # Este arquivo
├── css/
│   └── style.css           # Estilo único compartilhado (escuro, estética de caçador)
├── js/
│   └── ficha.js            # Cálculo automático de modificadores de atributos na ficha
├── pages/                  # 13 páginas de regras, cada uma HTML independente
│   ├── criacao.html        # 2 · Criação (7 passos, atributos, marcos +3/+5, sem compra de pontos)
│   ├── racas.html          # 3 · Raças (22 raças, orçamento racial, árvore de progressão 1/3/6/10, subcategorias)
│   ├── classes.html        # 4 · Classes (7 base + Fate [Saber, Archer, Lancer, Caster, Rider, Assassin] + Berserker, ganhos por nível estilo F&M)
│   ├── antecedentes.html   # 5 · Antecedentes (2 perícias, 1 ferramenta, 1 idioma, 1 item inicial, característica — HxH, D&D, Pathfinder 2e)
│   ├── aura.html           # 6 · Aura & Nen (Pontos de Aura, afinidade hexágono, princípios Ten/Zetsu/Ren/Gyo/In/En/Shu com custos fixos; Ten ativo custo elevado; Ken e Ko removidos)
│   ├── criacao-tecnicas.html # 7 · Criar Técnicas (Orçamento de Efeito PE, tabela de efeitos/preços, restrições/votos com teto, passo a passo, exemplo Excalibur!)
│   ├── combate.html        # 8 · Combate (turno 1 ação principal + 1 movimento + 1 bônus, PA = 7+SAB, Estamina, Vida em 3 partes, Investigar antes de Golpe Mirado, condições, reações, movimento, visão/furtividade)
│   ├── equipamentos.html   # 9 · Equipamentos (armas D&D/F&M/HxH, armaduras, graus de dano, qualidade, itens úteis, carga)
│   ├── estilos-luta.html   # 10 · Estilos de Luta (gerais, classe, raça, regra da brecha: Investigar obrigatório antes de golpe mirado)
│   ├── poderes-hb.html     # 11 · Homebrew de Poderes (8 hatsus do PDF do usuário reequilibrados: Excalibur!, Torre de Terra Celta, Capivara Zen, Intenção Assassina, Ilimitado, Spinjitsu, Assimilar, Criar)
│   ├── ficha.html          # 12 · Ficha (preenchível no navegador, imprimir/exportar PDF, JS para atributos)
│   └── mestre.html         # 13 · Guia do Mestre (Tabela de Ameaça NA 1-10, montando combates, papéis de NPC, técnicas de NPC, CD de tarefas, ranks de missão, progressão)
└── assets/imagens/         # Espaço vazio para imagens futuras
```

Cada página em `pages/` referencia o CSS em `../css/style.css`. A ficha carrega `../js/ficha.js`. Todas abram em qualquer navegador e podem ser impressas/exportadas em PDF.

---

## 3. O que já foi implementado (resumo por página)

| Página | Conteúdo principal |
|---|---|
| `index.html` | Capa, 5 princípios de ouro, resumo do turno, navegação por abas |
| `criacao.html` | 7 passos, atributos (conjunto padrão 15/14/13/12/10/8 ou 4d6), escala de atributos, marcos +3 e +5, atributos penalizados |
| `racas.html` | 22 raças (incluindo Nean, Lefou, Kuruta, etc.), orçamento racial, árvore de progressão com marcos 1/3/6/10, subcategorias, Traços de Quimera (Lefou), Módulos (Nean), Pecados do Tiefling, Mandamentos do Aasimar |
| `classes.html` | 7 classes base (Guerreiro, Bárbaro, Monge, Ladino, Patrulheiro, Médico, Estudioso) com tabela de ganhos por nível (estilo F&M), classes de Fate (Saber, Archer, Lancer, Caster, Rider, Assassin), Berserker (Sangue Fervente) |
| `antecedentes.html` | 14 antecedentes (gerais + HxH), cada um com 2 perícias, 1 ferramenta, 1 idioma, 1 item inicial nomeado e 1 característica |
| `aura.html` | Aura Máxima = 10 + (5×nível) + CON, afinidade de Nen (hexágono, custos por distância), 7 princípios (Ten, Zetsu, Ren, Gyo, In, En, Shu) com custo fixo em Aura, estados especiais (Condenado, Selado, Exposto) |
| `criacao-tecnicas.html` | Orçamento de Efeito (PE), tabela de efeitos e preços em PE, restrições/votos com teto (−2 PE, −20 Au), passo a passo, exemplo completo Excalibur! |
| `combate.html` | Iniciativa, turno curto, Estamina (10+2×CON, zerar = desorientado), Vida em 3 partes (estupefato ao mudar de parte), ações principais/bônus/reações, Investigar obrigatório antes de Golpe Mirado, movimento, visão/furtividade, acerto/dano, golpes mirados detalhados, condições, sem tabela de crítico fixa (mestre decide) |
| `equipamentos.html` | Propriedades de armas, escada de graus de dano, armas (D&D/F&M/HxH), armaduras, qualidade +1/+2/+3, itens úteis, carga (FOR×7 kg sem penalidade) |
| `estilos-luta.html` | Estilos para todos, para classes, para raças, regra da brecha (não se pode declarar golpe mirado sem Investigar primeiro) |
| `poderes-hb.html` | 8 hatsus reequilibrados do PDF do usuário com custo fixo em Aura, restrições escritas e penalidades |
| `ficha.html` | Ficha preenchível (PV, CA, Estamina, Aura, Sanidade, PA, PEH, atributos com JS automático, Hatsus, equipamentos, anotações) |
| `mestre.html` | Tabela de Ameaça (NA 1-10 com PV/CA/Ataque/Dano/CD/Aura), montando combates (Fácil/Normal/Difícil/Mortal), papéis de NPC, técnicas de NPC por NA, tabela de tarefas (CD 5-25), ranks E-C-B-A-S |

---

## 4. Decisões de design fixas (não mudar sem consultar o usuário)

1. **Base D&D 5e:** d20 + modificador vs CD/CA.
2. **Sem compra de pontos de atributo:** conjunto padrão ou rolagem 4d6.
3. **Turno curto:** 1 ação principal + 1 movimento + 1 ação bônus. Sem multiataque livre.
4. **PA = 7 + mod SAB:** reações gastam 1 PA cada.
5. **Todo poder tem preço:** técnicas montadas com orçamento PE. Restrições dão desconto com teto e penalidade escrita.
6. **Ten ativo, não passivo:** custo 5 Aura, +2 CA por 1 minuto (concentração).
7. **Ken e Ko removidos:** En e Shu polidos do jeito do HxH.
8. **Intimidar ≠ Provocar:** condições distintas conforme os livros.
9. **Golpe Mirado exige Investigar:** não se declara golpe mirado sem antes achar brecha na postura.
10. **Vida em 3 partes:** estupefato ao mudar de parte; penalidades por vida baixa (revertido no Berserker).
11. **Estamina:** barra de estabilidade; zerar = desorientado (sem agir no restante da rodada + próxima completa); recupera 4 por rodada sem dano.
12. **Sem tabela de crítico fixa:** o Mestre decide efeitos de 1 e 20 natural.
13. **Cada página é um HTML independente:** fácil de imprimir/exportar em PDF.

---

## 5. Como continuar o projeto (próximos passos sugeridos)

1. **Testar na mesa:** leve as páginas para uma sessão de jogo e veja o que funciona.
2. **Ajustar números:** se algum Hatsu, classe ou raça parecer desequilibrado na prática, mude o custo de Aura, PE ou efeito e faça um novo commit.
3. **Adicionar mais itens:** a tabela de equipamentos pode crescer com mais armas e armaduras dos livros do usuário.
4. **Criar mais hatsus:** use a página `criacao-tecnicas.html` como referência para novos hatsus do HB.
5. **Adicionar monstros/NPCs:** use a `mestre.html` (Tabela de Ameaça) para criar oponentes rapidamente.
6. **Gerar PDFs:** imprima cada página como PDF para entregar aos jogadores.

---

## 6. Regras do usuário (perfil — Sr. Maycom)

- Nome: Maycon. Não sabe programar. Idioma: português do Brasil. Windows 10.
- Estilo JARVIS: trate por "senhor" ou "Sr. Maycom", calmo, confiante, humor seco e sutil, direto e eficiente, honesto, demonstre iniciativa.
- Explicações simples, sem jargão; quando inevitável, explique em uma frase com comparações do cotidiano.
- Decisões importantes: apresente 2–3 opções com o que é, vantagens, desvantagens, para que tipo de projeto; diga sua recomendação e espere a escolha.
- Decisões pequenas: escolha sozinho e justifique em 1–2 frases.
- Cada projeto: pasta própria com LEIAME.md e controle de versão (git) com ponto de restauração a cada etapa que funcionar.
- Limites (pare e pergunte antes): dinheiro, criar contas, usar senhas/logins, publicar na internet, enviar mensagens/e-mails em seu nome, apagar arquivos fora de pastas de projeto, mexer em configurações do sistema, baixar programas de sites desconhecidos.

---

## 7. Como usar este contexto em uma nova sessão

1. Abra o Hermes em uma nova sessão.
2. Cole este texto inteiro como a primeira mensagem.
3. Diga ao Hermes: "Continue o projeto Nen5e em `C:\Users\Maycon\Documents\RPG_Nen5e`. Aqui está o contexto de transferência."
4. O Hermes saberá onde estão os arquivos, o que já foi feito e quais decisões já foram tomadas.

---

## 8. Últimos commits do git

- `v2.2` — corrige antecedentes: separa Ferramenta e Idioma em colunas distintas, remove placeholder "Jogo de Dragão"
- `v2.1` — reestrutura em pastas (css/, js/, pages/), antecedentes com itens iniciais específicos, equipamentos renomeados (D&D/F&M/HxH), ficha com JS externo
- `v2.0` — sistema dividido em 13 páginas (abas), raça com árvore, classes com ganhos por nível, estilo Fate, Berserker, estamina, vida em 3 partes, criação de técnicas com PE, homebrew de poderes, ficha, guia do mestre
- `v1.0` — sistema base (index.html), HB de poderes (poderes_hb.html), ficha (ficha.html), LEIAME.md

---

*Preparado para o Sr. Maycom. Direto, sem enrolar e pronto para a mesa.*
