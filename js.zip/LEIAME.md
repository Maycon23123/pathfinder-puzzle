# NEN5E — Sistema de RPG para Caçadores
**Projeto:** Reforma completa do sistema HxH da campanha do Sr. Maycon  
**Base mecânica:** D&D 5e (Livro do Jogador)  
**Sistema de poder:** Técnicas de Aura / Nen (baseado em F&M / Feiticeiros & Maldições e Aura RPG)  
**Versão:** 2.0 (estrutura dividida em páginas e pastas)

---

## Estrutura de pastas

```
RPG_Nen5e/
├── index.html              # Capa, como jogar, princípios, navegação
├── LEIAME.md               # Este arquivo
├── css/
│   └── style.css           # Estilo compartilhado de todas as páginas
├── js/
│   └── ficha.js            # Script de cálculo de modificadores da ficha
├── pages/                  # Todas as regras divididas por página
│   ├── criacao.html        # 2 · Criação (atributos, marcos, sem compra de pontos)
│   ├── racas.html          # 3 · Raças (22 raças, árvore de progressão, subcategorias)
│   ├── classes.html        # 4 · Classes (7 base + Fate + Berserker, ganhos por nível)
│   ├── antecedentes.html   # 5 · Antecedentes (com itens iniciais específicos)
│   ├── aura.html           # 6 · Aura & Nen (princípios, afinidade, custos fixos)
│   ├── criacao-tecnicas.html # 7 · Criar Técnicas (orçamento PE, restrições/votos)
│   ├── combate.html        # 8 · Combate (estamina, vida em 3 partes, golpes mirados)
│   ├── equipamentos.html   # 9 · Equipamentos (armas D&D/F&M/HxH, armaduras, itens)
│   ├── estilos-luta.html   # 10 · Estilos de Luta (gerais, classe, raça, regra da brecha)
│   ├── poderes-hb.html     # 11 · Homebrew de Poderes (8 hatsus reequilibrados)
│   ├── ficha.html          # 12 · Ficha (preenchível, com JS para atributos)
│   └── mestre.html         # 13 · Guia do Mestre (tabela de ameaça, NPC, progressão)
└── assets/imagens/         # Espaço para imagens futuras
```

Cada arquivo em `pages/` é um documento HTML independente. Abra qualquer um no navegador e imprima/exportar como PDF.

---

## O que mudou em relação ao sistema antigo

| Problema do velho sistema | Solução no NEN5E |
|---|---|
| Regras quebradas e cheias de buracos | Cada regra tem número fixo e exceções escritas; o mestre não "inventa" no meio da partida |
| Tudo depende do mestre | Combate, criação de poderes e avanço são resolvidos pelas fichas e tabelas |
| Sistema massivo e difícil de ler | 13 páginas separadas, leves, fáceis de imprimir ou exportar em PDF |
| Compra de atributos confusa | Conjunto padrão (15,14,13,12,10,8) ou rolagem 4d6 |
| Poucos ganhos por nível | Escolha de uma opção nova quase todo nível (estilo F&M), incluindo classes de Fate e Berserker |
| Raças sem progressão | Árvore de progressão racial com marcos (1, 3, 6, 10) e subcategorias |
| Criação de poderes vaga | Orçamento de efeito (PE) + restrições numéricas com teto, do F&M, detalhado |
| Ten passivo e fraco | Ten ativo: custo elevado, concede CA por curto período |
| Ken e Ko confusos | Removidos; En e Shu polidos do jeito do HxH |
| Intimidar = Provocar | Separados com condições distintas dos livros |
| Golpes mirados sem critério | Requer ação Investigar para achar brecha na postura antes de declarar |
| Vida sem impacto na luta | Vida em 3 partes; estupefato ao mudar de parte; penalidades por vida baixa (revertido no Berserker) |
| Sem estabilidade de combate | Barra de Estamina: reduzida por bloqueios, zerar deixa desorientado, recupera 4 por rodada sem dano |
| Antecedentes genéricos sem itens | Cada antecedente concede um item inicial específico (lista detalhada) |

---

## Principais decisões de design (e por quê)

**1. Base D&D 5e.**  
O d20 + modificador vs. CD/CA já é conhecido, rápido e deixa pouco espaço para discussão.

**2. Energia de Aura no lugar da magia.**  
Cada personagem tem Pontos de Aura fixos. Princípios (Ten, Zetsu, Ren, etc.) e Hatsus custam Aura. Não há slots de magia confusos.

**3. Criação de Hatsus com Restrições (Votos).**  
Vindo do F&M: você torna um hatasu mais forte ou mais barato adicionando restrições reais. Quanto maior a restrição, maior o benefício, com teto e penalidade escrita.

**4. Combate com Ações fixas.**  
Cada turno = 1 Ação Principal + 1 Movimento + 1 Ação Bônus. Reações são um recurso limitado (PA = 7 + SAB).

**5. Estamina e Vida em 3 partes.**  
Estamina mede estabilidade em combate; zerar deixa desorientado. Vida em 3 partes gera estupor ao mudar de parte e penalidades por vida baixa (revertido no Berserker).

**6. Golpes mirados exigem brecha.**  
Não se pode declarar golpe mirado sem antes investigar o alvo e encontrar uma falha na postura (ação Investigar).

---

## Controle de versão

Este projeto está sob git na pasta `C:\Users\Maycon\Documents\RPG_Nen5e`. A cada etapa que funcionar, faremos um commit para você ter um ponto de restauração.

---

*Preparado para o Sr. Maycom. Direto, sem enrolar e pronto para a mesa.*
